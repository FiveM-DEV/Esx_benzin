Locales['de'] = {
	['carry_for_leaves'] = 'Benutze ~INPUT_CONTEXT~ um das Oil zu sammeln',
	['take_oil'] = 'Benutze ~INPUT_CONTEXT~ um Benzin herzustellen',
	['sell_benzin'] = 'Benutze ~INPUT_CONTEXT~ um das Benzin zu Verkaufen',
	['bag_full'] = 'Dein inventar ist voll.',
	['take_oil'] = '~y~Nehme Oil~s~...',
	['you_do_not_have_enough_oil'] = 'Du hast nicht genug oil zum Refinen.',
	['you_do_not_have_any_more_oil'] = 'Du hast kein ~r~Oil~s~ mehr',
	['transform_benzin'] = '~y~Um Oil umzuwandeln~s~...',
	['you_do_not_have_benzin'] = 'Du hast keinen ~r~Benzin~s~ mehr',
	['sell_benzin'] = 'Du verkaufst ~y~x1~s~ ~y~Benzin~s~',
	['sell_benzin'] = '~g~Um das Benzin zu verkaufen~s~...',
	-- Blips 
	['oil_picking'] = 'Oil Sammelstelle',
	['turns_from_benzin'] = 'Oil Refinery',
	['sell_juice_benzin_blip'] = 'Benzin Verkauf',
}