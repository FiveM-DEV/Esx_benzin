INSERT INTO `items` (name, label, `limit`) VALUES
	('oil', 'Oil', 500),
	('benzin', 'Benzin', 100)
;